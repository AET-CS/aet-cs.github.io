package connectfour.player;

import connectfour.model.Board;
import connectfour.model.GameState;
import connectfour.model.Piece;

import java.util.Random;
import java.util.function.IntConsumer;

public class MinMaxPlayer extends Player {
    private final int depth;
    private final Random random;
    private IntConsumer depthDisplayCallback;

    public MinMaxPlayer(String name, int maxDepth) {
        super(name);
        this.depth = maxDepth;
        this.random = new Random();
        this.depthDisplayCallback = ignored -> {
        };
    }

    public void setDepthDisplayCallback(IntConsumer depthDisplayCallback) {
        this.depthDisplayCallback = depthDisplayCallback == null ? ignored -> {
        } : depthDisplayCallback;
    }

    @Override
    public int getMove(Board board, Piece color) {
        depthDisplayCallback.accept(depth);

       return 0;
    }

    private double minimax(Board board, int depthRemaining, Piece turn) {
      GameState state = board.getGameState();
      return 0;
    }

}
