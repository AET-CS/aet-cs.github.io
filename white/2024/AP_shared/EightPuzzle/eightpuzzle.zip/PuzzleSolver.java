import java.util.*;

public class PuzzleSolver {
}
