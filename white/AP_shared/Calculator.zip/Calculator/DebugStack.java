import java.util.Stack;

public class DebugStack<T> extends Stack<T> {

}
