
public class Stack<E> extends LinkedList<E> {

    public Stack() {
    }

    public void push(E item) {
    }


    public E pop() {
    }


    public E peek() {
		}


    public boolean isEmpty() {
    }


    public int size() {
    }

		// return index of E or -1 if not found
    public int search(E e) {
    }

    public void clear() {
		}

    @Override
    public String toString() {
		}
}
