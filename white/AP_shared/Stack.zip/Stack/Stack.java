
public class Stack<E> extends LinkedList<E> {

    public Stack() {
    }

    public void push(E item) {
    }


    public E pop() {
    }


    public E peek() {
		}


    public boolean isEmpty() {
    }


    public int size() {
    }


    public int search(E e) {
    }

    public void clear() {
		}

    @Override
    public String toString() {
		}
}
